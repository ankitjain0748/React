import './App.css';
import React, { useEffect, useState } from 'react'
import { BrowserRouter as Router,Route,Routes } from 'react-router-dom';
// import Message from './Component/Message';
import io from 'socket.io-client';
import Chat from './Component/Chat';
import ChatShow from './Component/ChatShow';
import Reg from './Component/Reg';
import Login from './Component/Login';
const socket = io.connect('http://localhost:8000');

function App() {
 
  useEffect(() => {
    // Handle incoming chat messages from the server
    socket.on('chatMessage', (data) => {
      console.log('Received chat message:', data);
      // Update your React component with the received data
    });


    return () => {
      socket.disconnect();
    };
  },[]);

  return (
    <div>
      <Router>
        <Routes>
          <Route path="/chat" element={<Chat/>}></Route>
          <Route path='/chatshow'element={<ChatShow/>}></Route>
          <Route path='/reg' element={<Reg/>}>
         

          </Route>
          <Route path='/' element={<Login/>}></Route>
        </Routes>
      </Router>
    
  </div>
  
  );
}

export default App;
