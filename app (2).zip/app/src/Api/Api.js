import axios from 'axios';
import io from 'socket.io-client';

const socket = io.connect('http://localhost:8000');


let Api = axios.create({  
    baseURL: "http://localhost:8000",
    headers : {
        "Content-Type": "application/json",
    }
});
export default Api;

