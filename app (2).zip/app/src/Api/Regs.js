import Api from "./Api";
import {Component} from 'react'

class Register extends Component {
    async Regshow(key) {
        return Api.post('/reg', key)
    }

    async Loginshow(key) {
        return Api.post('/login', key)
    }
}

export default Register;