
import React, { useState } from 'react';
import Form from 'react-bootstrap/Form';
import { Link } from 'react-router-dom';
import Register from '../Api/Regs';

function Reg() {
  const [Regs, SetRegs] = useState({
    name: '',
    password: '',
    email: '',
    username: '',
    confirmpassword: ''
  });

  const handleInputs = (e) => {
    let valueattr = e.target.value;
    let nameattr = e.target.name;
    SetRegs({ ...Regs, [nameattr]: valueattr });
    console.table(Regs);
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    const main = new Register();
   const resp=main.Regshow(Regs)
   resp.then((res)=>{
    console.log(res.data.user)
   }).then((err)=>{
    console.log(err)
   })
  };

  return (
    <section id="reg">
      <div className="container">
        <div className="row">
          <div className="col-md-3"></div>
          <div className="col-md-6 mr-2">
            <Form>
              <h2>Registration</h2>
              <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Username</Form.Label>
                <Form.Control
                  type="text"
                  defaultValue={Regs.username}
                  onChange={handleInputs}
                  name="username"
                  placeholder="username"
                />
              </Form.Group>
              <Form.Group className="mb-3" controlId="exampleForm.ControlInput2">
                <Form.Label>Name</Form.Label>
                <Form.Control
                  type="text"
                  defaultValue={Regs.name}
                  onChange={handleInputs}
                  name="name"
                  placeholder="name"
                />
              </Form.Group>
              <Form.Group className="mb-3" controlId="exampleForm.ControlInput3">
                <Form.Label>Email address</Form.Label>
                <Form.Control
                  type="email"
                  defaultValue={Regs.email}
                  onChange={handleInputs}
                  name="email"
                  placeholder="name@example.com"
                />
              </Form.Group>
              <Form.Group className="mb-3" controlId="exampleForm.ControlInput4">
                <Form.Label>Password</Form.Label>
                <Form.Control
                  type="password"
                  defaultValue={Regs.password}
                  onChange={handleInputs}
                  name="password"
                  placeholder="Password"
                />
              </Form.Group>
              <Form.Group className="mb-3" controlId="exampleForm.ControlInput5">
                <Form.Label>Confirm Password</Form.Label>
                <Form.Control
                  type="password"
                  defaultValue={Regs.confirmpassword}
                  onChange={handleInputs}
                  name="confirmpassword"
                  placeholder="Confirm Password"
                />
              </Form.Group>
              <button variant="primary" className="form-control" onClick={handleFormSubmit}>
                Submit
              </button>
            </Form>
          <Link to="/">Login Here</Link>
          </div>
          <div className="col-md-3"></div>
        </div>
      </div>
    </section>
  );
}

export default Reg;
