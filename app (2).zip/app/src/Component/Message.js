import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';

function Message() {
    const [messages, setMessages] = useState([]);
    const socket = io.connect('http://localhost:3000'); // Use the correct server URL and port

    useEffect(() => {
        socket.on('chatMessage', (data) => {
            console.table("message recived", data);
        });
        return () => {
            socket.disconnect();
        };
    }, []);

    const handleSendMessage = (message) => {
        socket.emit('chat message', message);
    }

    return (
        <section id="message">
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div>
                            <ul>
                            <input type="text"/>
                            </ul>
                            <input type="text" />
                            <button onClick={() => handleSendMessage('Hello!')}>Send</button>
                        </div>

                    </div>
                </div>
            </div>
        </section>



    );
}

export default Message;