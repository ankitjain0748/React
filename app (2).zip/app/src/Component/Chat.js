import React, { useEffect, useState, useRef } from "react";
import Messages from "../Api/Messages";
import ScrollToBottom from 'react-scroll-to-bottom';

function Chat() {
 const [messages, setMessages] = useState("");
  const chatContainerRef = useRef(null);

  const handleChat = (e) => {
    setMessages(e.target.value);
  }

  function handleSubmit(e) {
    e.preventDefault();
    const main = new Messages();
    const formData = new FormData();
    formData.append("message", messages);
    const Chatss = main.MessageChat(formData);
    Chatss.then((res) => {
      setMessages("");
    }).catch((err) => {
      console.log(err);
    });
  }

  const [chat, setChat] = useState([]);
  useEffect(() => {
    const main = new Messages();
    const resp = main.MessageChatShow();
    resp.then((res) => {
      setChat(res.data.data);
      scrollToBottom();
    }).catch((err) => {
      console.log(err);
    });
  }, []);

  const scrollToBottom = () => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      const main = new Messages();
      const resp = main.MessageChatShow();
      resp.then((res) => {
        setChat(res.data.data);
      }).catch((err) => {
        console.log(err);
      });
    }, 1); // Fetch messages every 2 seconds (adjust as needed)

    return () => {
      clearInterval(interval); // Clear interval on component unmount
    };
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [chat]);

  return (
    <section id="chat">
      <div className='chat warpper'>
        <div className="chats-list mt-2">
          <ScrollToBottom className='chats-list' ref={chatContainerRef}>
            <div className="message-container">
              {chat &&
                chat.map((res) => (
                  <div key={res._id} >
                    <div className="message-content">{res.message}</div>
                  </div>
                ))}
            </div>
          </ScrollToBottom>
        </div>

        <div className='chats-actions d-flex align-items-center justify-content-center'>
          <input
            type="text"
            value={messages}
            placeholder='Enter the message'
            name={"messages"}
            onChange={handleChat}
          />
          <button onClick={handleSubmit} className='btn btn-success ms-2'>Send</button>
        </div>
      </div>
    </section>
  );
}

export default Chat;


//className={`message-wrapper ${message.user === 1 ? 'right' : 'left'}`}