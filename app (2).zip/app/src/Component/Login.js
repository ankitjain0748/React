import React, { useState } from 'react';
import Register from '../Api/Regs';
import Form from 'react-bootstrap/Form';
import { useNavigate } from 'react-router-dom';

function Login() {
  const navigate = useNavigate();
  const [Regs, setRegs] = useState({
    password: "",
    username: "",
  });

  const handleInputs = (e) => {
    const value = e.target.value;
    const name = e.target.name;
    setRegs((prevState) => ({ ...prevState, [name]: value }));
    console.table(Regs);
  };

  async function handleForms(e) {
    e.preventDefault(); // Prevent form submission

    const main = new Register();
    try {
      const res = await main.Loginshow(Regs);
      console.log(res.data.user);
      setRegs(res.data.user);
      navigate('/chat'); // Navigating to the chat page
    } catch (err) {
      console.log(err);
    }
  }

  return (
    <section id="login">
      <section id="reg">
        <div className="container">
          <div className="row">
            <div className="col-md-3"></div>
            <div className="col-md-6">
              <h2>Login</h2>
              <Form onSubmit={handleForms}>
                <Form.Group className="mb-3" controlId="formPlaintextEmail">
                  <Form.Label column sm="2">
                    Email/Username
                  </Form.Label>
                  <Form.Control
                    name="username"
                    onChange={handleInputs}
                    type="text"
                    value={Regs.username}
                    placeholder="Email/Username"
                  />
                </Form.Group>

                <Form.Group className="mb-3" controlId="formPlaintextPassword">
                  <Form.Label column sm="2">
                    Password
                  </Form.Label>
                  <Form.Control
                    name="password"
                    onChange={handleInputs}
                    value={Regs.password}
                    type="password"
                    placeholder="Password"
                  />
                </Form.Group>
                <button type="submit" className="form-control">
                  Submit
                </button>
              </Form>
            </div>
            <div className="col-md-3"></div>
          </div>
        </div>
      </section>
    </section>
  );
}

export default Login;
