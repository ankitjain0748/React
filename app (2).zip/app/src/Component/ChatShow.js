import { useEffect, useState } from "react";
import Messages from "../Api/Messages";

function ChatShow() {
    const [chat, setChat] = useState([])
    useEffect(() => {
        const main = new Messages();
        const resp = main.MessageChatShow()
        resp.then((res) => {
            console.log(res.data.data);
            setChat(res.data.data)
        }).catch((err) => {
            console.log(err)
        })
    })
    return (
        <section id="chatshow">
            <div className="container">
                <div className="row">
                    <div className="col-md-12">

                        <table className="table table-hover table-responsive">
                            <thead>

                                <tr>
                                    <th>S.No</th>
                                    <th>Message</th>
                                    <th>Messager Id</th>
                                </tr>
                            </thead>
                            <tbody>
                                {chat && chat.map((res, key) => (

                                    <tr key={res._id}>
                                        <td>{key + 1}</td>
                                        <td>{res.message}</td>
                                        <td>{res._id}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>




                    </div></div></div>
        </section>

    );
}

export default ChatShow;